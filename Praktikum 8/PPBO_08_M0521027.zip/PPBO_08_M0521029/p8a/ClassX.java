
/* Nama : Hanina Nafisa Azka
    NIM : M0521027
*/

package com.java.p8a;
import com.java.p8.Buku; //meengimport class Buku pada com.java.p8

public class ClassX {
    public static void main(String[] args) {
        // buat objek buku
        Buku buku = new Buku("432A326B4", "Pengenalan Komputasi Cloud", "Eri Suhardi", "Elex Media Komputindo", 2022);
        // tampilkan data buku lewat method printDataBuku
        buku.printDataBuku();
        // akses ke variabel yang ada di objek buku
        System.out.println(buku.isbn);
        System.out.println(buku.judul);
        System.out.println(buku.penulis);
        System.out.println(buku.penerbit);
        System.out.println(buku.tahunTerbit);
    }
}

/*Error yang terdapat pada code diatas terdapat pada
  ".isbn" pada line ke-16, ".penulis" pada line ke-18, ".tahunTerbit" pada line ke-20
  disebabkan karena attribute dari masing-maing error, "isbn", "penulis", dan "tahunTerbit" pada file Buku.java
  dalam pakage "com.java.p8.Buku" memiliki acces modifier private dan tidak adanya class Buku pada package com.java.p8a. 
  Class Buku hanya ada pada package com.java.p8
*/