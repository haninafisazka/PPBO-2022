
/* Nama : Hanina Nafisa Azka
    NIM : M0521027
*/
package com.java.p8a;
import com.java.p8.Buku; //meengimport class Buku pada com.java.p8

import com.java.p8.Buku;

public class BukuInherit extends Buku {
    public BukuInherit(String isbn, String judul, String penulis, String penerbit, int tahunTerbit) {
    super(isbn, judul, penulis, penerbit, tahunTerbit);
    super.isbn = isbn;
    super.judul = judul;
    super.penulis = penulis;
    super.penerbit = penerbit;
    super.tahunTerbit = tahunTerbit;
    }
}

/*Error yang terdapat pada code diatas terdapat pada
  "super.isbn" pada line ke-13, "super.penulis" pada line ke-15, "super.tahunTerbit" pada line ke-17
  (pada code diatas ditambahkan "import com.java.p8.Buku")
  disebabkan attribute dari masing-maing error, "isbn", "penulis", dan "tahunTerbit" pada file Buku.java
  dalam pakage "com.java.p8.Buku" memiliki acces modifier private.
*/