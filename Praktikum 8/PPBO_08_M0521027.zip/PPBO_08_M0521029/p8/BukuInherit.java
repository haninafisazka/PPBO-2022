
/* Nama : Hanina Nafisa Azka
    NIM : M0521027
*/
package com.java.p8;

public class BukuInherit extends Buku {
    public BukuInherit(String isbn, String judul, String penulis, String penerbit, int tahunTerbit) {
        super(isbn, judul, penulis, penerbit, tahunTerbit);
        super.isbn = isbn;
        super.judul = judul;
        super.penulis = penulis;
        super.penerbit = penerbit;
        super.tahunTerbit = tahunTerbit;
    }
}

/*Error yang terdapat pada code diatas terdapat pada "super.penulisan" pada line ke-12
  Error ini terjadi disebabkan attribute pada "penulis" pada file 
  Buku.java (no 1 pada modul) memiliki acces modifier berjenis private
  yang menyebabkan hanya dapat diakses dalam class tersebut (class Buku).
*/