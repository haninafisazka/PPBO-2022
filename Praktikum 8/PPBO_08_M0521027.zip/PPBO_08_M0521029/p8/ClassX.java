
/* Nama : Hanina Nafisa Azka
    NIM : M0521027
*/
package com.java.p8;

public class ClassX {
    public static void main(String[] args) {
       // buat objek buku
       Buku buku = new Buku("432A326B4", "Pengenalan Komputasi Cloud","Eri Suhardi", "Elex Media Komputindo", 2022);
       // tampilkan data buku lewat method printDataBuku
       buku.printDataBuku();
       // akses ke variabel yang ada di objek buku
       System.out.println(buku.isbn);
       System.out.println(buku.judul);
       System.out.println(buku.penulis);
       System.out.println(buku.penerbit);
       System.out.println(buku.tahunTerbit);
    }
}

/*Error yang terdapat pada code diatas terdapat pada ".penulisan" pada line ke-16
  Error ini terjadi disebabkan attribute pada "penulis" pada file 
  Buku.java (no 1 pada modul) memiliki acces modifier berjenis private
  yang menyebabkan hanya dapat diakses dalam class tersebut (class Buku).
*/